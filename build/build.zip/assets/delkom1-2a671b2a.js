const s="/assets/delkom1-66e9f634.jpg";export{s as b};
